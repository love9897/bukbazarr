# book_app

A new Flutter project.

<p float="left">
  <img src="https://github.com/ahmedoid/book_app/blob/master/Simulator%20Screen%20Shot%20-%20iPhone%208%20-%202018-07-02%20at%2013.29.48.png?raw=true" width="270" />
  <img src="https://github.com/ahmedoid/book_app/blob/master/Simulator%20Screen%20Shot%20-%20iPhone%208%20-%202018-07-02%20at%2013.29.52.png?raw=true" width="270" /> 
  <img src="https://github.com/ahmedoid/book_app/blob/master/Simulator%20Screen%20Shot%20-%20iPhone%208%20-%202018-07-02%20at%2013.29.56.png?raw=true" width="270" />
</p>

[Youtube](https://www.youtube.com/watch?v=OPRursZGuvU)

## Getting Started

For help getting started with Flutter, view our online
[documentation](https://flutter.io/).
